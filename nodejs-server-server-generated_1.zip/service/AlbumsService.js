'use strict';


/**
 * Delete Album
 *
 * id Long 
 * no response value expected for this operation
 **/
exports.deleteAlbum = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Musicas from a specific Album
 *
 * id Long 
 * returns List
 **/
exports.musicasAlbumID = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "nomealbum" : "nomealbum",
  "nomeartista" : "nomeartista"
}, {
  "nomealbum" : "nomealbum",
  "nomeartista" : "nomeartista"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

