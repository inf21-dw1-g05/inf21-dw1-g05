'use strict';


/**
 * Create User
 *
 * body User  (optional)
 * returns User
 **/
exports.createUser = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "nome" : "nome",
  "pais" : "pais",
  "email" : "email"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete User
 *
 * id Long 
 * no response value expected for this operation
 **/
exports.deleteUser = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * show Users
 *
 * returns List
 **/
exports.showUsers = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "nome" : "nome",
  "pais" : "pais",
  "email" : "email"
}, {
  "nome" : "nome",
  "pais" : "pais",
  "email" : "email"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * show Users with ID
 *
 * id Long 
 * returns User
 **/
exports.showUsersID = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "nome" : "nome",
  "pais" : "pais",
  "email" : "email"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update User
 *
 * body User 
 * id Long 
 * no response value expected for this operation
 **/
exports.updateUser = function(body,id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

