'use strict';


/**
 * Create Artista
 *
 * body Artista  (optional)
 * returns Artista
 **/
exports.createArtista = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "nomeartista" : "nomeartista",
  "pais" : "pais"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete Artista
 *
 * id Long 
 * no response value expected for this operation
 **/
exports.deleteArtista = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Show Artistas
 *
 * returns List
 **/
exports.showArtista = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "nomeartista" : "nomeartista",
  "pais" : "pais"
}, {
  "nomeartista" : "nomeartista",
  "pais" : "pais"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * show Artista with ID
 *
 * id Long 
 * returns Artista
 **/
exports.showArtistaID = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "nomeartista" : "nomeartista",
  "pais" : "pais"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update Artista
 *
 * body Artista 
 * id Long 
 * no response value expected for this operation
 **/
exports.updateArtista = function(body,id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

