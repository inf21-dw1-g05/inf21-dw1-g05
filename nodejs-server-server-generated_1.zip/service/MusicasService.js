'use strict';


/**
 * All Musicas
 *
 * returns List
 **/
exports.allMusicas = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "genero" : "genero",
  "nomeartista" : "nomeartista",
  "nomeMusicaa" : "Musica"
}, {
  "genero" : "genero",
  "nomeartista" : "nomeartista",
  "nomeMusicaa" : "Musica"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create Musica
 *
 * body Musica  (optional)
 * returns Musica
 **/
exports.createMusica = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "genero" : "genero",
  "nomeartista" : "nomeartista",
  "nomeMusicaa" : "Musica"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete Musica
 *
 * id Long 
 * no response value expected for this operation
 **/
exports.deleteMusicca = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * show Musica with ID
 *
 * id Long 
 * returns Musica
 **/
exports.showMusicaID = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "genero" : "genero",
  "nomeartista" : "nomeartista",
  "nomeMusicaa" : "Musica"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update Musica
 *
 * body Musica 
 * id Long 
 * no response value expected for this operation
 **/
exports.updateMusica = function(body,id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

