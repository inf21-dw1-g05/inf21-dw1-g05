'use strict';

var utils = require('../utils/writer.js');
var Artistas = require('../service/ArtistasService');

module.exports.createArtista = function createArtista (req, res, next, body) {
  Artistas.createArtista(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteArtista = function deleteArtista (req, res, next, id) {
  Artistas.deleteArtista(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.showArtista = function showArtista (req, res, next) {
  Artistas.showArtista()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.showArtistaID = function showArtistaID (req, res, next, id) {
  Artistas.showArtistaID(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateArtista = function updateArtista (req, res, next, body, id) {
  Artistas.updateArtista(body, id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
