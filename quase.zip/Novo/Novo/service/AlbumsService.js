'use strict';

var sql = require('../utils/db.js');
/**
 * Delete Album
 *
 * id Long 
 * no response value expected for this operation
 **/
exports.deleteAlbum = function(id) {
  return new Promise(function(resolve, reject) {
  sql.query("DELETE FROM Album WHERE id= ?", [id], function(err, res)
  {
    if (err || !res.affectedRows){
      console.log(err);
      console.log(res);
      reject();
    }
    else{
      console.log(res);
      resolve({"deleted":id});
    }
  });

  });
}


/**
 * Musicas from a specific Album
 *
 * id Long 
 * returns List
 **/
exports.musicasAlbumID = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "nomealbum" : "nomealbum",
  "nomeartista" : "nomeartista"
}, {
  "nomealbum" : "nomealbum",
  "nomeartista" : "nomeartista"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}