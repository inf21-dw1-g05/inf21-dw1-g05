'use strict';

var utils = require('../utils/writer.js');
var Albums = require('../service/AlbumsService');

module.exports.deleteAlbum = function deleteAlbum (req, res, next, id) {
  Albums.deleteAlbum(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.musicasAlbumID = function musicasAlbumID (req, res, next, id) {
  Albums.musicasAlbumID(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
